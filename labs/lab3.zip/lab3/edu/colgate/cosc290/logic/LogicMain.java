// Colgate University COSC 290 Labs
// Version 0.1,  2017
// Author: Michael Hay
package edu.colgate.cosc290.logic;

/**
 * A main class where students can demonstrate the correctness of their implementation.
 */
public class LogicMain {

    /**
     * A short demonstration that illustrates (with three example propositions) how a proposition
     * can be converted into CNF.
     * @param args
     */
    public static void main(String[] args) {
        throw new UnsupportedOperationException("implement me!");
    }
}
