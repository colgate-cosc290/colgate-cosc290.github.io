# Lab 2: Sat Solver

- Course: COSC 290 Discrete Structures Spring 2018
- Instructor: Michael Hay
- Assignment: Lab 2
- Due dates: XXX (see instructions about "submitting your work" below)
- Starter code: [here](XXX)

XXX hello! test 2! XXX

## Instructions

## Basic setup

See the instructions in Lab 1 for setting up the work environment, compiling code, running code, saving your work, and turning in your work.

## Background

XXX explain the following things:

- problem
- real-world applications
- reading: 3.3.3 and CS Connection, p. 326 (which talks about P vs. NP)
- DPLL pseudocode
- model
- experiment
- science paper(s)
- experiment spec: what should the experiment do?
- heuristics: pure and unit, role of model

## Your tasks

Your *primary* task is to implement the `SatSolver` and in particular the `isSatisfiableHelper()` method.  Once it's completed, you can experiment with it in `ExperimentMain` and then enhance it using the.  However, there are several other classes that are provided and some of them have methods that you are asked to fill in.  These additional classes

### Suggested plan of attack

I suggest you complete tasks in the following order.  As you go, think about how what you're coding might be useful for the `SatSolver`

1. Warmup: get familiar with the code and implement the following helper methods: `Literal.toString()`, `Clause.getVariables()`, `Clause.getPositiveVariables`, `Clause.getNegativeVariables`, and `CNFF.getVariables()`.
2. Implement `Model.isTrue()` and `Model.isFalse()`.  These should come in handy in `isSatisfiableHelper`.
3. `SatSolver.isSatisfiableHelper()`.  Implement a "simple" version that does not prioritize pure variables and variables in unit clauses.
4. Replicate the experiment described above in `ExperimentMain` using the "simple version."
5. Now write the code to look for unit clauses and pure variables `FormulaAnalyzers.findUnitClauseVariables` and `FormulaAnalyzers.findPureVariables`.
6. Incorporate the `FormulaAnalyzers` methods into `SatSolver.isSatisfiableHelper()`

The following classes are provided: `FormulaGenerator`, `Pair`, `Variable`.  You should read them but you should not need to modify them.



XXX add challenge problem? further optimizations, super-challenge problem, present a poly time algorithm XXX
