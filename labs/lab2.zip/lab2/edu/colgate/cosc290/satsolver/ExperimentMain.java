package edu.colgate.cosc290.satsolver;

/**
 * A class for running experiments on randomly generated CNFF formulas
 *
 * Colgate University COSC 290 Labs
 * Version 0.1,  2017
 *
 * @author Michael Hay
 */
public class ExperimentMain {

    /**
     * See lab description.
     * @param args
     */
    public static void main(String[] args) {
        throw new UnsupportedOperationException("implement me!");
    }
}
