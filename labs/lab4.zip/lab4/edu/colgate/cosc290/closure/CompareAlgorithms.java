// Colgate University COSC 290 Labs
// Version 0.1,  2017
// Author: Michael Hay
package edu.colgate.cosc290.closure;


/**
 * A simple class that contains a main method for comparing algorithm runtimes.
 */
public class CompareAlgorithms {

    /**
     * Compare the runtimes of the two methods for transitive closure.  {@see System#currentTimeMillis()}
     * @param args
     */
    public static void main(String[] args) {
        throw new UnsupportedOperationException("implement me!");
    }
}
